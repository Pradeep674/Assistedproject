package com.spring.prob6;

import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;
@Component
@Aspect

public class LoggingAspect {
	
	 @Before("execution(* com.mphasis.ShoppingCart.getItems())")
	    public void logGetItems() {
	        System.out.println("Logging: Retrieving items from shopping cart.");
	    }
	 
	    @Before("execution(* com.mphasis.ShoppingCart.addItem(..))")
	    public void logAddItem() {
	        System.out.println("Logging: Adding item to shopping cart.");
	    }
	 
	    @Before("execution(* com.mphasis.ShoppingCart.removeItem(..))")
	    public void logRemoveItem() {
	        System.out.println("Logging: Removing item from shopping cart.");
	    }
	 
	    @Before("execution(* com.mphasis.ShoppingCart.updateItem(..))")
	    public void logUpdateItem() {
	        System.out.println("Logging: Updating item in shopping cart.");
	    }
	 
	    @AfterReturning("execution(* com.mphasis.ShoppingCart.*(..))")
	    public void logAfterReturning() {
	        System.out.println("Logging: Action completed successfully.");
	    }
	 
	    @AfterThrowing("execution(* com.mphasis.ShoppingCart.*(..))")
	    public void logAfterThrowing() {
	        System.out.println("Logging: An exception occurred during action execution.");
	    }

}
