package com.spring.prob6;

import org.springframework.context.ApplicationContext;

import org.springframework.context.support.ClassPathXmlApplicationContext;
public class Main {
	
	 public static void main(String[] args) {
	        // Load the Spring configuration
	        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("spring-config.xml");
	 
	        // Retrieve the ShoppingCart bean
	        ShoppingCart cart = context.getBean("shoppingCart", ShoppingCart.class);
	 
	        // Perform some actions on the shopping cart
	        cart.addItem("Item 1");
	        cart.addItem("Item 2");
	        cart.removeItem("Item 1");
	 
	        // Close the context
	        context.close();
	    }

}
