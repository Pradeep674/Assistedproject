package com.spring.prob6;

import java.util.List;

public class ShoppingCart {
	
	 private List<String> items;
	 
	    public List<String> getItems() {
	        return items;
	    }
	 
	    public void addItem(String item) {
	        // Add item to the cart
	    }
	 
	    public void removeItem(String item) {
	        // Remove item from the cart
	    }
	 
	    public void updateItem(String oldItem, String newItem) {
	        // Update item in the cart
	    }

}
