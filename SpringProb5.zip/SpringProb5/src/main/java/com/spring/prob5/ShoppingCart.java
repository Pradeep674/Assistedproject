package com.spring.prob5;

import java.util.List;

public class ShoppingCart {

	  private List<String> items;
	  
	    public List<String> getItems() {
	        return items;
	    }
	 
	    public void setItems(List<String> items) {
	        this.items = items;
	    }
	
}
