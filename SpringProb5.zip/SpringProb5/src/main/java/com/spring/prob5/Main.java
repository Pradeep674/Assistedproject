package com.spring.prob5;
import org.springframework.context.support.ClassPathXmlApplicationContext;


import java.io.IOException;

public class Main {
	
	 public static void main(String[] args) {
	        // Bootstrap the Spring core container
	        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("spring-config.xml");
	 
	        // Retrieve the Cashier bean
	        Cashier cashier = (Cashier) context.getBean("cashierBean");
	 
	        // Test checkout functionality
	        ShoppingCart cart = new ShoppingCart();
	        // Add items to the cart...
	 
	        try {
	            cashier.checkout(cart);
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	 
	        // Close the application context
	        context.close();
	 }

}
