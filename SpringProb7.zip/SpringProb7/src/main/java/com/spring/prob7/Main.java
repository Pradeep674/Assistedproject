package com.spring.prob7;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {
 
	 public static void main(String[] args) {
	        try (AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class)) {
	            ShoppingCart cart = context.getBean(ShoppingCart.class);
	            Cashier cashier = context.getBean(Cashier.class);
	 
	            cart.addItem("Item 1");
	            cart.addItem("Item 2");
	            cart.removeItem("Item 1");
	 
	            cashier.checkout(cart);
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
	
}
