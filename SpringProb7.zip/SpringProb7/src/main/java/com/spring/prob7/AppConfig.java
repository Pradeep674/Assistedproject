package com.spring.prob7;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
 
@Configuration
@ComponentScan("com.example")

public class AppConfig {
	
	  @Bean(initMethod = "openFile", destroyMethod = "closeFile")
	    public Cashier cashier() {
	        return new Cashier();
	    }

}
