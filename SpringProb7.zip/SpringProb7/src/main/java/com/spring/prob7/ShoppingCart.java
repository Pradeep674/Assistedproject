package com.spring.prob7;

import java.util.ArrayList;
import java.util.List;

public class ShoppingCart {
	 private List<String> items = new ArrayList<>();
	 
	    public List<String> getItems() {
	        return items;
	    }
	 
	    public void addItem(String item) {
	        items.add(item);
	    }
	 
	    public void removeItem(String item) {
	        items.remove(item);
	    }
	 
	    public void updateItem(String oldItem, String newItem) {
	        int index = items.indexOf(oldItem);
	        if (index != -1) {
	            items.set(index, newItem);
	        }
	    }
	

}
